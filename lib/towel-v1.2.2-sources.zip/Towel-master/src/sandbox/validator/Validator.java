package sandbox.validator;

public class Validator {

}
