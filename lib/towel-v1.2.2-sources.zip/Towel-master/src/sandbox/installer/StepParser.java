package sandbox.installer;

public class StepParser {
	public static Step parse(String cfg){
		return null;
	}
}
