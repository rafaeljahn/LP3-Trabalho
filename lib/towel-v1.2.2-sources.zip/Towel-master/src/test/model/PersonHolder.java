package test.model;

public class PersonHolder {
	private EPerson person;

	public void setPerson(EPerson person) {
		this.person = person;
	}

	public EPerson getPerson() {
		return person;
	}
}
