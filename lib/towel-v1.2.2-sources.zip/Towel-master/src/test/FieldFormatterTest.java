package test;


public class FieldFormatterTest {

}
