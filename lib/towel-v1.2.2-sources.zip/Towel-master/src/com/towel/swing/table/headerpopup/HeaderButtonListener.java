package com.towel.swing.table.headerpopup;

import java.util.EventListener;

/**
 * @author Vinicius Godoy
 */
public interface HeaderButtonListener extends EventListener
{
    void buttonClicked(HeaderPopupEvent e);
}
