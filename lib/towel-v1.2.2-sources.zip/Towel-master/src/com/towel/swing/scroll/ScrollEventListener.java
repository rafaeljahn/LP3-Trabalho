package com.towel.swing.scroll;

public interface ScrollEventListener {
	public void scrollPerformed(ScrollEvent event);
}
