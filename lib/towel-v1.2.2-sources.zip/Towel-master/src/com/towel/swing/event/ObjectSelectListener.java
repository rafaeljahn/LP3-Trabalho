package com.towel.swing.event;

public interface ObjectSelectListener {
	public void notifyObjectSelected(SelectEvent selectevent);
}