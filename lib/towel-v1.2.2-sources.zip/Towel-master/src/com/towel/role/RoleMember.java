package com.towel.role;

public interface RoleMember {
	public String getRoleName();
}
