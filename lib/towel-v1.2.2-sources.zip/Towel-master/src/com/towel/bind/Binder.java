package com.towel.bind;

public interface Binder {
	public void updateModel(Object obj);
	public void updateView(Object obj);
}
